<!-- ***** Footer section start ***** -->
<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="col-md-4 pr-30">
        <div class="footer_about">
          <h3>about us</h3>
          <div class="line-title-left"></div>
          <p class="text-white">Lorem ipsum dolor sit amet, eu me seo  laboramus, iudico dummy  text <br>vituperatoribus at usu cum ex nostrud singulis, vis et nibh</p>
        </div>
        <div class="footer_subscribe">
          <h5>subcribe now</h5>
        <div class="input-group">
                <input type="text" class="form-control" placeholder="Enter your email here">
                <span class="input-group-btn">
                    <button type="submit"><i class="fa fa-paper-plane"></i></button>
                </span>
            </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="latest_posts">
          <h3>latest posts</h3>
          <div class="line-title-left"></div>
          <ul class="post-link">
          <li>
            <a href="#">If you need a crown or <br>lorem an implant you will pay it gap</a>
            <br>
            <span>July 2, 2014</span>
          </li>
          <li>
            <a href="#">If you need a crown or <br>lorem an implant you will pay it gap</a>
            <br>
            <span>July 2, 2014</span>
          </li>
        </ul>
        </div>
      </div>
      <div class="col-md-4">
        <div class="footer_address">
          <h3>address</h3>
          <div class="line-title-left"></div>
          <ul class="address-list">
          <li>
            <p><i class="fas fa-map-marker"></i>60 Grant Ave. Carteret NJ 0708</p>
          </li>
          <li>
            <p><i class="fas fa-mobile-alt"></i>(880) 1723801729</p>
          </li>
          <li>
            <p><i class="far fa-envelope"></i>example@gmail.com</p>
          </li>
        </ul>
        <ul class="footer_social list-inline">
          <li class="list-inline-item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
          <li class="list-inline-item"><a href="#"><i class="fab fa-twitter"></i></a></li>
          <li class="list-inline-item"><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
          <li class="list-inline-item"><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
          <li class="list-inline-item"><a href="#"><i class="fab fa-vimeo-v"></i></a></li>
        </ul>
        </div>
      </div>
    </div>
  </div>
</footer>
<div class="sub-footer">
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <p class="text-center">
        Theme Created By <a href="#">CodeGlamour.</a> All Rights Reserved.
      </p>
    </div>
  </div>
</div>
</div>