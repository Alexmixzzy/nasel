
<!DOCTYPE html>
        <html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="description" content="Fitness HTML Template">
	<meta name="author" content="CodeGlamour">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Enegix - Investment</title>
	<!--Favicon-->
    <link rel="shortcut icon" href="../static/public/images/favicon.ico" type="image/x-icon">
	<link rel="icon" href="../static/public/images/favicon.ico" type="image/x-icon">
    <!-- Google font (font-family: 'Montserrat', sans-serif;) -->
	<!-- <link href="../static/public/fonti/cssf757.css?family=Montserrat:400,500,600,700" rel="stylesheet"> -->
    <link href="../static/public/fonti/cssf757.css" rel="stylesheet">
	<!-- Google font (font-family: 'Open Sans', sans-serif;) -->
	<!-- <link href="../static/public/fonti/css44ae.css?family=Open+Sans:300i,400,400i,600,700" rel="stylesheet"> -->
    <link href="../static/public/fonti/css44ae.css" rel="stylesheet">
    <!-- Bootstrap Css-->
    <link rel="stylesheet" type="text/css" href="../static/public/css/bootstrap.css">
    <!-- Icons Css-->
    <link rel="stylesheet" type="text/css" href="../static/public/css/themify-icons.css">
    <!-- Font Awesome Css-->
    <link rel="stylesheet" type="text/css" href="../static/public/css/fontawesome-all.min.css">
    <!-- OWL Carousel Css-->
    <link rel="stylesheet" type="text/css" href="../static/public/css/owl.carousel.min.css">
    <!-- Slick Css -->
    <link rel="stylesheet" type="text/css" href="../static/public/css/slick.css">
    <!-- Magnific Popup Css -->
    <link rel="stylesheet" type="text/css" href="../static/public/css/magnific-popup.css">
    <!-- Custom Css -->
	<link rel="stylesheet" type="text/css" href="../static/public/css/style.css">
    <!-- Paradise Slider Main Style Sheet -->
    <link href="../static/public/css/full_width_animated_layers_002.css" rel="stylesheet" media="all">
</head>

