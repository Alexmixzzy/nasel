
<!-- Vendor JS Files -->

<!-- Template Main JS File -->

<!-- Jquery-2.2.4 JS -->
<script src="../static/public/js/jquery-2.2.4.min.js"></script>
<!-- login JS -->
<script src="../static/public/js/login.js"></script>
<!-- Bootstrap-4 Beta JS -->
<script src="../static/public/js/bootstrap.min.js"></script>
<!-- Touch Swipe JS File Version - 1.6.18 -->
<script src="../static/public/js/jquery.touchSwipe.min.js"></script>
<!-- Paradise Slider Main JS File -->
<script src="../static/public/js/paradise_slider_min.js"></script>
<!--Jquery Easing Js -->
<script src="../static/public/cdnjs/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
<!--Slick Js -->
<script src="../static/public/js/slick.min.js"></script>
<!--Magnific Popup Js -->
<script src="../static/public/js/magnific-popup.js"></script>
<!--OWL Carousel Js -->
<script src="../static/public/js/owl-carousel.min.js"></script>	
<!-- Custom JS -->
<script src="../static/public/js/custom.js"></script>