
<!-- Container fluid start -->
<div class="container-fluid">
    <!-- Row start -->
    <div class="row gutters">
        <div class="col-12">
            <!-- Footer start -->
            <div class="footer">
                Copyright <?php $site->voidSite('name'); ?> @ <?php $obj->voidCal(date("Y")); ?>
            </div>
            <!-- Footer end -->
        </div>
    </div>
    <!-- Row end -->
</div>
<!-- Container fluid end -->

<!-- Chat start -->
<!-- Chat end -->	