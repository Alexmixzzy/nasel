<!--**************************
			**************************
				**************************
							Required JavaScript Files
				**************************
			**************************
		**************************-->
		<!-- Required jQuery first, then Bootstrap Bundle JS -->
		<script src="../static/secure/js/jquery.min.js"></script>
		<script src="../static/secure/js/bootstrap.bundle.min.js"></script>
		<script src="../static/secure/js/moment.js"></script>


		<!-- *************
			************ Vendor Js Files *************
		************* -->
		<!-- Slimscroll JS -->
		<script src="../static/secure/vendor/slimscroll/slimscroll.min.js"></script>
		<script src="../static/secure/vendor/slimscroll/custom-scrollbar.js"></script>

		<!-- Polyfill JS -->
		<script src="../static/secure/vendor/polyfill/polyfill.min.js"></script>
		<script src="../static/secure/vendor/polyfill/class-list.min.js"></script>

		<!-- Apex Charts -->
		<script src="../static/secure/vendor/apex/apexcharts.min.js"></script>
		<script src="../static/secure/vendor/apex/custom/graph-widgets/line-graph8.js"></script>
		
		<!-- Peity Charts -->
		<script src="../static/secure/vendor/peity/peity.min.js"></script>
		<script src="../static/secure/vendor/peity/custom-peity.js"></script>
		
		<!-- Rating JS -->
		<script src="../static/secure/vendor/rating/raty.js"></script>
		<script src="../static/secure/vendor/rating/raty-custom.js"></script>

		<!-- jVector Maps -->
		<script src="../static/secure/vendor/jvectormap/jquery-jvectormap-2.0.3.min.js"></script>
		<script src="../static/secure/vendor/jvectormap/gdp-data.js"></script>
		<script src="../static/secure/vendor/jvectormap/world-mill-en.js"></script>
		<!-- Custom JVector Maps -->
		<script src="../static/secure/vendor/jvectormap/custom/world-map-markers.js"></script>

		<!-- Circleful Charts -->
		<script src="../static/secure/vendor/circliful/circliful.min.js"></script>
		<script src="../static/secure/vendor/circliful/circliful.custom.js"></script>
		
		<!-- Main JS -->
		<script src="../static/secure/js/main.js"></script>