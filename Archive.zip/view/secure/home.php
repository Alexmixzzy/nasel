<?php echo 'Welcome to Dashboard '; echo $obj->model->getUser('fullname'); ?>
<br>
<?php echo $obj->args('fullname','sgs','shs','peter'); ?>