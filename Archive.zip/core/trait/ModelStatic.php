<?php

trait ModelStaticTrait{

    public $sessionUser = 'auth_user';
    public $sessionEmail = 'auth_email';
    public $dashBoard = '../dashboard/';
    public $loginPage = '../login/';
    public $logOutPath = '../logout/';
}

?>