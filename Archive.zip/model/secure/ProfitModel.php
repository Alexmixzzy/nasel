<?php 

class ProfitModel
{

    protected  $balance  = 0;
    public $model;


    public function __construct($models){
    $this->model = $models;

    } 

    


    
}



?>