<?php 

interface UserModelInterFace {

    public function get($data,$clause);
}

?>